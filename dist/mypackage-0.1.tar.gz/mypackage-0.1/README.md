# mypackage

This library was created as a tutorial on how to publish your own python package.

# How to install
... 